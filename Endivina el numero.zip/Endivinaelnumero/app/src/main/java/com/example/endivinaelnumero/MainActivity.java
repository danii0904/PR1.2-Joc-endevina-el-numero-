package com.example.endivinaelnumero;

import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Scanner;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button button = findViewById(R.id.button);
        final EditText text = (EditText) findViewById(R.id.text);
        final int numeroCorrecto = (int) (Math.random()*10);

        Scanner sc = new Scanner(System.in);

        button.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                final int num = Integer.parseInt(text.getText().toString());

                if (num == numeroCorrecto){
                    Toast.makeText(MainActivity.this, "NUMERO CORRECTE", Toast.LENGTH_SHORT).show();
                }
                else if (num > numeroCorrecto){
                    Toast.makeText(MainActivity.this, "EL NUMERO ES MES PETIT", Toast.LENGTH_SHORT).show();
                }
                else if (num < numeroCorrecto){
                    Toast.makeText(MainActivity.this, "EL NUMERO ES MES GRAN", Toast.LENGTH_SHORT).show();
                }
            }


        });


    }
}